
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ChatScreen from './screens/ChatScreen';
import DocumentScreen from './screens/DocumentScreen';
import CasePredictionScreen from './screens/CasePredictionScreen';
import RightsAdviceScreen from './screens/RightsAdviceScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Chat" component={ChatScreen} />
        <Stack.Screen name="Document Generator" component={DocumentScreen} />
        <Stack.Screen name="Case Prediction" component={CasePredictionScreen} />
        <Stack.Screen name="Rights Advice" component={RightsAdviceScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
