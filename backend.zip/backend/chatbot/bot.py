def ask_legal_question(question):
    # Simple dummy response
    return f"Legal answer to: {question}"
