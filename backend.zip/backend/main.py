from fastapi import FastAPI
from chatbot.bot import ask_legal_question
from document_gen.generator import generate_document
from case_predictor.predictor import predict_case_outcome
from rights_module.advisor import suggest_rights

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Legal Buddy API is running"}

@app.post("/chatbot/")
def chatbot_endpoint(question: str):
    return {"response": ask_legal_question(question)}

@app.post("/generate-document/")
def document_endpoint(doc_type: str, details: str):
    return {"document": generate_document(doc_type, details)}

@app.post("/predict-case/")
def case_predictor_endpoint(case_facts: str):
    return {"outcome": predict_case_outcome(case_facts)}

@app.post("/rights/")
def rights_advisor_endpoint(user_profile: str):
    return {"advice": suggest_rights(user_profile)}
