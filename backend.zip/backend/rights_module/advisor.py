def suggest_rights(user_profile):
    return "Your rights include legal aid, privacy, and due process."
