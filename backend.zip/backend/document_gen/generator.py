def generate_document(doc_type, details):
    return f"Generated {doc_type} with the following details: {details}"
